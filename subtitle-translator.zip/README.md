
# Subtitle Translator Tool

🧠 自动识别字幕语言  
🌍 多语言翻译（中、英、日）  
⚡ 多线程翻译，支持 .srt/.vtt/.ass  
🎯 一键构建 Windows EXE via GitHub Actions
